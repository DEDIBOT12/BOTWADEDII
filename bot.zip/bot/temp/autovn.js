//KETIKA ADA YANG TOXIC
exports.vnToxic = [
//Jangan toxic pm
"https://cdn.filestackcontent.com/Zdfunz5gQLeTCF4DlQOW",
//Heeh
"https://cdn.filestackcontent.com/YYG9wdIgRLSHi5Or45dO"
]
exports.vnMenu = ["https://sf16-ies-music-va.tiktokcdn.com/obj/musically-maliva-obj/7321048497540188934.mp3"]
